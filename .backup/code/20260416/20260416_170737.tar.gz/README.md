# NEPSE Stock Dashboard V2

A modern, robust NEPSE stock market analysis system with live data, technical analysis, and ML-powered predictions.

## Features

- **Live Data** - Real-time prices from NEPSE official API
- **Technical Analysis** - RSI, MACD, Bollinger Bands, Moving Averages
- **Floorsheet Analytics** - Broker buying/selling patterns
- **ML Predictions** - Ensemble (Rule + ML) recommendations
- **Portfolio Tracking** - Track holdings and P/L
- **Auto-Refresh** - Updates during trading hours

## Installation

```bash
# Clone repository
git clone https://github.com/YOUR_USERNAME/nepse-stockmarket-v2.git
cd nepse-stockmarket-v2

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt
```

## Quick Start

```bash
# Run dashboard
streamlit run app/main.py
```

Dashboard will open at: http://localhost:8501

## Project Structure

```
nepse-stockmarket-v2/
├── app/                    # Streamlit application
│   ├── pages/             # Dashboard pages
│   └── components/        # Reusable components
├── core/                  # Core functionality
│   ├── data/             # Data layer
│   ├── analysis/          # Technical analysis
│   └── ml/               # Machine learning
├── config/                # Configuration
├── scripts/              # Utility scripts
├── data/                 # Local data
├── tests/                # Unit tests
├── requirements.txt
└── README.md
```

## Data Sources

- **Primary:** NEPSE Official API via `nepse-data-api`
- **Backup:** YONEPSE JSON API

## License

MIT License
