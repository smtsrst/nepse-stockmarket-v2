"""
NEPSE Data Client - Wrapper for nepse-data-api with mock fallback.
"""

from typing import Optional, Dict, List, Any
from functools import lru_cache

from app.core import mock_data


class NepseClient:
    """Client for accessing NEPSE data via nepse-data-api."""

    def __init__(self):
        self._client = None
        self._cache: Dict[str, tuple[Any, float]] = {}
        self._cache_ttl = 60  # seconds

    def _get_client(self):
        """Lazy initialization of nepse-data-api client."""
        if self._client is None:
            try:
                from nepse_data_api import Nepse

                self._client = Nepse(cache_ttl=30, enable_cache=True)
            except ImportError:
                raise ImportError(
                    "nepse-data-api not installed. Run: pip install nepse-data-api"
                )
        return self._client

    def _get_cached(self, key: str) -> Optional[Any]:
        """Get cached data if not expired."""
        if key in self._cache:
            data, timestamp = self._cache[key]
            import time

            if time.time() - timestamp < self._cache_ttl:
                return data
        return None

    def _set_cached(self, key: str, data: Any) -> None:
        """Cache data with timestamp."""
        import time

        self._cache[key] = (data, time.time())

    def get_market_status(self) -> Dict[str, Any]:
        """Get market open/closed status."""
        cache_key = "market_status"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        if mock_data.MOCK_MODE:
            result = {"isOpen": True, "message": "Market Open (Mock Mode)"}
            self._set_cached(cache_key, result)
            return result

        client = self._get_client()
        try:
            result = client.get_market_status()
            self._set_cached(cache_key, result)
            return result
        except Exception as e:
            return {"isOpen": False, "error": str(e)}

    def get_market_summary(self) -> Dict[str, Any]:
        """Get market summary (turnover, volume, etc.)."""
        cache_key = "market_summary"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        if mock_data.MOCK_MODE:
            result = mock_data.get_mock_market_summary()
            self._set_cached(cache_key, result)
            return result

        client = self._get_client()
        try:
            result = client.get_market_summary()
            # Handle list format from NEPSE API
            if isinstance(result, list):
                parsed = {}
                for item in result:
                    detail = item.get("detail", "")
                    value = item.get("value", 0)
                    if "Turnover" in detail and "Total" in detail:
                        parsed["totalTurnover"] = value
                    elif "Traded Shares" in detail:
                        parsed["totalShare"] = value
                    elif "Transactions" in detail and "Total" in detail:
                        parsed["totalTrade"] = value
                    elif "Scrips" in detail:
                        parsed["totalCompanies"] = value
                result = parsed
            self._set_cached(cache_key, result)
            return result
        except Exception as e:
            return {"error": str(e)}

    def get_nepse_index(self) -> Dict[str, Any]:
        """Get NEPSE index values."""
        cache_key = "nepse_index"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        if mock_data.MOCK_MODE:
            result = mock_data.get_mock_index()
            self._set_cached(cache_key, result)
            return result

        client = self._get_client()
        try:
            result = client.get_nepse_index()
            self._set_cached(cache_key, result)
            return result
        except Exception as e:
            return {"error": str(e)}

    def get_sub_indices(self) -> List[Dict[str, Any]]:
        """Get sector indices."""
        cache_key = "sub_indices"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        client = self._get_client()
        try:
            result = client.get_sub_indices()
            self._set_cached(cache_key, result)
            return result
        except Exception as e:
            return []

    def get_stocks(self) -> List[Dict[str, Any]]:
        """Get live stock prices."""
        cache_key = "stocks"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        if mock_data.MOCK_MODE:
            result = mock_data.get_mock_stocks()
            self._set_cached(cache_key, result)
            return result

        client = self._get_client()
        try:
            # Try get_price_volume first (has most data)
            result = client.get_price_volume()
            if not result:
                # Fallback to get_stocks
                result = client.get_stocks()
            # Handle empty or invalid response
            if not result:
                return []
            # Normalize the data format
            normalized = []
            for stock in result:
                if isinstance(stock, dict):
                    normalized.append(
                        {
                            "symbol": stock.get("symbol", ""),
                            "name": stock.get(
                                "securityName", stock.get("companyName", "")
                            ),
                            "lastTradedPrice": stock.get(
                                "lastTradedPrice", stock.get("ltp", 0)
                            ),
                            "openPrice": stock.get(
                                "openPrice", stock.get("previousClose", 0)
                            ),
                            "highPrice": stock.get("highPrice", 0),
                            "lowPrice": stock.get("lowPrice", 0),
                            "volume": stock.get(
                                "totalTradeQuantity", stock.get("volume", 0)
                            ),
                            "percentageChange": stock.get(
                                "percentageChange", stock.get("change", 0)
                            ),
                        }
                    )
            self._set_cached(cache_key, normalized)
            return normalized
        except Exception as e:
            return []

    def get_top_gainers(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top gaining stocks."""
        cache_key = f"top_gainers_{limit}"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        client = self._get_client()
        try:
            result = client.get_top_gainers(limit=limit)
            # Normalize format
            normalized = []
            for stock in result:
                if isinstance(stock, dict):
                    normalized.append(
                        {
                            "symbol": stock.get("symbol", ""),
                            "name": stock.get("securityName", ""),
                            "lastTradedPrice": stock.get(
                                "ltp", stock.get("lastTradedPrice", 0)
                            ),
                            "percentageChange": stock.get("percentageChange", 0),
                        }
                    )
            self._set_cached(cache_key, normalized)
            return normalized
        except Exception as e:
            return []

    def get_top_losers(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top losing stocks."""
        cache_key = f"top_losers_{limit}"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        client = self._get_client()
        try:
            result = client.get_top_losers(limit=limit)
            # Normalize format
            normalized = []
            for stock in result:
                if isinstance(stock, dict):
                    normalized.append(
                        {
                            "symbol": stock.get("symbol", ""),
                            "name": stock.get("securityName", ""),
                            "lastTradedPrice": stock.get(
                                "ltp", stock.get("lastTradedPrice", 0)
                            ),
                            "percentageChange": stock.get("percentageChange", 0),
                        }
                    )
            self._set_cached(cache_key, normalized)
            return normalized
        except Exception as e:
            return []

    def get_floorsheet(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get floorsheet data."""
        cache_key = f"floorsheet_{symbol or 'all'}"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        client = self._get_client()
        try:
            result = client.get_floorsheet(symbol=symbol)
            self._set_cached(cache_key, result)
            return result
        except Exception as e:
            return []

    def get_market_depth(self, symbol: str) -> Dict[str, Any]:
        """Get market depth (order book)."""
        client = self._get_client()
        try:
            return client.get_market_depth(symbol=symbol)
        except Exception as e:
            return {"error": str(e)}

    def get_security_details(self, security_id: int) -> Dict[str, Any]:
        """Get company/security details."""
        client = self._get_client()
        try:
            return client.get_security_details(security_id=security_id)
        except Exception as e:
            return {"error": str(e)}

    def get_company_list(self) -> List[Dict[str, Any]]:
        """Get list of all companies."""
        cache_key = "company_list"
        cached = self._get_cached(cache_key)
        if cached is not None:
            return cached

        if mock_data.MOCK_MODE:
            result = mock_data.get_mock_company_list()
            self._set_cached(cache_key, result)
            return result

        client = self._get_client()
        try:
            result = client.get_company_list()
            self._set_cached(cache_key, result)
            return result
        except Exception as e:
            return []

    def get_company_news(self, symbol: str) -> List[Dict[str, Any]]:
        """Get news for a company."""
        client = self._get_client()
        try:
            return client.get_company_news(symbol=symbol)
        except Exception as e:
            return []

    def get_historical_chart(
        self, security_id: int, start_date: str, end_date: str
    ) -> List[Dict[str, Any]]:
        """Get historical price data."""
        if mock_data.MOCK_MODE:
            # Generate mock history based on security_id
            from datetime import datetime, timedelta

            end_d = (
                datetime.strptime(end_date, "%Y-%m-%d") if end_date else datetime.now()
            )
            start_d = (
                datetime.strptime(start_date, "%Y-%m-%d")
                if start_date
                else end_d - timedelta(days=30)
            )
            days = (end_d - start_d).days
            return mock_data.get_mock_history(f"STK{security_id}", days)

        client = self._get_client()
        try:
            return client.get_historical_chart(
                security_id=security_id, start_date=start_date, end_date=end_date
            )
        except Exception as e:
            return []


# Global client instance
@lru_cache(maxsize=1)
def get_nepse_client() -> NepseClient:
    """Get singleton NepseClient instance."""
    return NepseClient()
