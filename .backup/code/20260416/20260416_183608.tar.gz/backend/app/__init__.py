"""NEPSE Stock Dashboard Backend."""
