"""
Market data API endpoints.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional

from app.core.client import get_nepse_client
from app.core.analysis import analyze_stock

router = APIRouter(prefix="/market", tags=["Market Data"])


@router.get("/status")
def get_market_status():
    """Get market open/closed status."""
    client = get_nepse_client()
    data = client.get_market_status()
    return {
        "is_open": data.get("isOpen", False),
        "message": "Market is open" if data.get("isOpen") else "Market is closed",
    }


@router.get("/summary")
def get_market_summary():
    """Get market summary (turnover, volume, etc.)."""
    client = get_nepse_client()
    data = client.get_market_summary()

    # Handle both dict and list responses
    if isinstance(data, list):
        # If it's a list, extract first item or return empty
        if data and len(data) > 0:
            data = data[0] if isinstance(data[0], dict) else {}
        else:
            data = {}
    elif not isinstance(data, dict):
        data = {}

    return {
        "total_turnover": data.get("totalTurnover"),
        "total_trade": data.get("totalTrade"),
        "total_share": data.get("totalShare"),
        "total_companies": data.get("totalCompanies"),
    }


@router.get("/indices")
def get_market_indices():
    """Get NEPSE index and sector indices."""
    client = get_nepse_client()

    # NEPSE index
    index_data = client.get_nepse_index()

    # Sector indices
    sub_indices = client.get_sub_indices()

    return {
        "nepse_index": {
            "index_value": index_data.get("indexValue"),
            "index_change": index_data.get("indexChange"),
            "index_change_percent": index_data.get("indexChangePercent"),
            "float_index_value": index_data.get("floatIndexValue"),
            "sensitive_index_value": index_data.get("sensitiveIndexValue"),
        },
        "sector_indices": sub_indices,
    }
